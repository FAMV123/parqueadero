--
-- PostgreSQL database dump
--

\restrict kpAmxlA5aDycexKMPMq3r4mMuWDCBMbhgH4ksQl8unUtz02OiyJn9GbfbrZsO9Q

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--



--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: limpiar_registros_antiguos(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.limpiar_registros_antiguos(dias integer DEFAULT 90) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  limite   timestamptz;
  borrados integer;
begin
  if dias < 30 then
    raise exception 'Por seguridad, el mínimo es 30 días';
  end if;

  limite := ((now() at time zone 'America/Bogota')::date - dias)::timestamp at time zone 'America/Bogota';

  insert into resumen_diario (fecha, tipo, cantidad, total)
  select (salida at time zone 'America/Bogota')::date, tipo, count(*), coalesce(sum(valor), 0)
  from registros
  where estado = 'salio' and salida < limite
  group by 1, 2
  on conflict (fecha, tipo) do update
    set cantidad = resumen_diario.cantidad + excluded.cantidad,
        total    = resumen_diario.total    + excluded.total;

  delete from registros where estado = 'salio' and salida < limite;
  get diagnostics borrados = row_count;
  return borrados;
end;
$$;


--
-- Name: tamano_bd(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tamano_bd() RETURNS bigint
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$ select pg_database_size(current_database()); $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cierres_caja; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cierres_caja (
    id bigint NOT NULL,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    usuario text DEFAULT ''::text NOT NULL,
    desde timestamp with time zone,
    hasta timestamp with time zone,
    cantidad integer DEFAULT 0 NOT NULL,
    detalle jsonb DEFAULT '{}'::jsonb NOT NULL,
    total_sistema integer DEFAULT 0 NOT NULL,
    efectivo_contado integer DEFAULT 0 NOT NULL,
    diferencia integer DEFAULT 0 NOT NULL,
    mens_entradas integer DEFAULT 0 NOT NULL,
    observaciones text DEFAULT ''::text NOT NULL,
    revisado boolean DEFAULT false NOT NULL,
    revisado_en timestamp with time zone,
    nota_admin text DEFAULT ''::text NOT NULL,
    mens_pagos integer DEFAULT 0 NOT NULL,
    mens_valor integer DEFAULT 0 NOT NULL
);


--
-- Name: cierres_caja_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cierres_caja ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.cierres_caja_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: configuracion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configuracion (
    id integer DEFAULT 1 NOT NULL,
    nombre text DEFAULT 'PARQUEADERO'::text NOT NULL,
    nit text DEFAULT ''::text NOT NULL,
    direccion text DEFAULT ''::text NOT NULL,
    telefono text DEFAULT ''::text NOT NULL,
    mensaje text DEFAULT 'Gracias por su visita. No nos hacemos responsables por objetos dejados en el vehículo.'::text NOT NULL,
    ancho_papel text DEFAULT '58'::text NOT NULL,
    CONSTRAINT configuracion_ancho_papel_check CHECK ((ancho_papel = ANY (ARRAY['58'::text, '80'::text]))),
    CONSTRAINT configuracion_id_check CHECK ((id = 1))
);


--
-- Name: gastos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gastos (
    id bigint NOT NULL,
    fecha date DEFAULT CURRENT_DATE NOT NULL,
    concepto text NOT NULL,
    valor integer DEFAULT 0 NOT NULL,
    creado timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT gastos_valor_check CHECK ((valor >= 0))
);


--
-- Name: gastos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.gastos ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.gastos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mensualidades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mensualidades (
    id bigint NOT NULL,
    placa text NOT NULL,
    tipo text NOT NULL,
    propietario text DEFAULT ''::text NOT NULL,
    telefono text DEFAULT ''::text NOT NULL,
    valor integer DEFAULT 0 NOT NULL,
    fecha_inicio date DEFAULT CURRENT_DATE NOT NULL,
    fecha_fin date NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    dentro boolean DEFAULT false NOT NULL,
    creado timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mensualidades_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mensualidades ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mensualidades_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: movimientos_mensualidad; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.movimientos_mensualidad (
    id bigint NOT NULL,
    mensualidad_id bigint,
    placa text NOT NULL,
    tipo text NOT NULL,
    movimiento text NOT NULL,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT movimientos_mensualidad_movimiento_check CHECK ((movimiento = ANY (ARRAY['entrada'::text, 'salida'::text])))
);


--
-- Name: movimientos_mensualidad_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.movimientos_mensualidad ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.movimientos_mensualidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pagos_mensualidad; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pagos_mensualidad (
    id bigint NOT NULL,
    mensualidad_id bigint,
    placa text NOT NULL,
    tipo text NOT NULL,
    propietario text DEFAULT ''::text NOT NULL,
    valor integer DEFAULT 0 NOT NULL,
    desde date,
    hasta date NOT NULL,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    usuario text DEFAULT ''::text NOT NULL,
    en_caja boolean DEFAULT true NOT NULL,
    clase text DEFAULT 'renovacion'::text NOT NULL,
    cierre_id bigint,
    CONSTRAINT pagos_mensualidad_clase_check CHECK ((clase = ANY (ARRAY['nueva'::text, 'renovacion'::text])))
);


--
-- Name: pagos_mensualidad_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.pagos_mensualidad ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.pagos_mensualidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: registros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registros (
    id bigint NOT NULL,
    placa text NOT NULL,
    tipo text NOT NULL,
    entrada timestamp with time zone DEFAULT now() NOT NULL,
    salida timestamp with time zone,
    minutos integer,
    valor integer,
    estado text DEFAULT 'dentro'::text NOT NULL,
    cierre_id bigint,
    CONSTRAINT registros_estado_check CHECK ((estado = ANY (ARRAY['dentro'::text, 'salio'::text])))
);


--
-- Name: registros_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.registros ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.registros_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: resumen_diario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resumen_diario (
    fecha date NOT NULL,
    tipo text NOT NULL,
    cantidad integer DEFAULT 0 NOT NULL,
    total integer DEFAULT 0 NOT NULL
);


--
-- Name: tarifas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tarifas (
    tipo text NOT NULL,
    valor_hora integer DEFAULT 0 NOT NULL,
    minutos_gracia integer DEFAULT 5 NOT NULL,
    tope_dia integer DEFAULT 0 NOT NULL,
    actualizado timestamp with time zone DEFAULT now() NOT NULL,
    nombre text DEFAULT ''::text NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    orden integer DEFAULT 0 NOT NULL,
    valor_mes integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: cierres_caja; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cierres_caja (id, fecha, usuario, desde, hasta, cantidad, detalle, total_sistema, efectivo_contado, diferencia, mens_entradas, observaciones, revisado, revisado_en, nota_admin, mens_pagos, mens_valor) FROM stdin;
\.


--
-- Data for Name: configuracion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configuracion (id, nombre, nit, direccion, telefono, mensaje, ancho_papel) FROM stdin;
1	H Y F PARKING		CARRERA 25 # 28-64	3102789613	Agradecemos su visita. Le recordamos retirar sus objetos de valor y pertenencias del vehículo. Conserve este tiquete; es indispensable para la salida.	80
\.


--
-- Data for Name: gastos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gastos (id, fecha, concepto, valor, creado) FROM stdin;
\.


--
-- Data for Name: mensualidades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mensualidades (id, placa, tipo, propietario, telefono, valor, fecha_inicio, fecha_fin, activo, dentro, creado) FROM stdin;
\.


--
-- Data for Name: movimientos_mensualidad; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.movimientos_mensualidad (id, mensualidad_id, placa, tipo, movimiento, fecha) FROM stdin;
\.


--
-- Data for Name: pagos_mensualidad; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pagos_mensualidad (id, mensualidad_id, placa, tipo, propietario, valor, desde, hasta, fecha, usuario, en_caja, clase, cierre_id) FROM stdin;
\.


--
-- Data for Name: registros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.registros (id, placa, tipo, entrada, salida, minutos, valor, estado, cierre_id) FROM stdin;
\.


--
-- Data for Name: resumen_diario; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resumen_diario (fecha, tipo, cantidad, total) FROM stdin;
\.


--
-- Data for Name: tarifas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tarifas (tipo, valor_hora, minutos_gracia, tope_dia, actualizado, nombre, activo, orden, valor_mes) FROM stdin;
moto	1000	5	8000	2026-11-09 22:31:45.510869+00	Moto	t	1	60000
carro	3000	5	25000	2026-11-09 22:31:45.510869+00	Carro	t	2	150000
bicicleta	500	5	3000	2026-11-09 22:33:23.15156+00	Bicicleta	t	3	30000
\.


--
-- Name: cierres_caja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cierres_caja_id_seq', 1, false);


--
-- Name: gastos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gastos_id_seq', 1, false);


--
-- Name: mensualidades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mensualidades_id_seq', 1, false);


--
-- Name: movimientos_mensualidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.movimientos_mensualidad_id_seq', 1, false);


--
-- Name: pagos_mensualidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pagos_mensualidad_id_seq', 1, false);


--
-- Name: registros_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.registros_id_seq', 1, false);


--
-- Name: cierres_caja cierres_caja_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cierres_caja
    ADD CONSTRAINT cierres_caja_pkey PRIMARY KEY (id);


--
-- Name: configuracion configuracion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuracion
    ADD CONSTRAINT configuracion_pkey PRIMARY KEY (id);


--
-- Name: gastos gastos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_pkey PRIMARY KEY (id);


--
-- Name: mensualidades mensualidades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mensualidades
    ADD CONSTRAINT mensualidades_pkey PRIMARY KEY (id);


--
-- Name: mensualidades mensualidades_placa_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mensualidades
    ADD CONSTRAINT mensualidades_placa_key UNIQUE (placa);


--
-- Name: movimientos_mensualidad movimientos_mensualidad_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_mensualidad
    ADD CONSTRAINT movimientos_mensualidad_pkey PRIMARY KEY (id);


--
-- Name: pagos_mensualidad pagos_mensualidad_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagos_mensualidad
    ADD CONSTRAINT pagos_mensualidad_pkey PRIMARY KEY (id);


--
-- Name: registros registros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registros
    ADD CONSTRAINT registros_pkey PRIMARY KEY (id);


--
-- Name: resumen_diario resumen_diario_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resumen_diario
    ADD CONSTRAINT resumen_diario_pkey PRIMARY KEY (fecha, tipo);


--
-- Name: tarifas tarifas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tarifas
    ADD CONSTRAINT tarifas_pkey PRIMARY KEY (tipo);


--
-- Name: cierres_fecha_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cierres_fecha_idx ON public.cierres_caja USING btree (fecha);


--
-- Name: gastos_fecha_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gastos_fecha_idx ON public.gastos USING btree (fecha);


--
-- Name: movimientos_fecha_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX movimientos_fecha_idx ON public.movimientos_mensualidad USING btree (fecha);


--
-- Name: pagos_mens_fecha_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pagos_mens_fecha_idx ON public.pagos_mensualidad USING btree (fecha);


--
-- Name: pagos_mens_sin_cierre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pagos_mens_sin_cierre ON public.pagos_mensualidad USING btree (id) WHERE (en_caja AND (cierre_id IS NULL));


--
-- Name: registros_placa_dentro; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX registros_placa_dentro ON public.registros USING btree (placa) WHERE (estado = 'dentro'::text);


--
-- Name: registros_salida_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX registros_salida_idx ON public.registros USING btree (salida);


--
-- Name: registros_sin_cierre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX registros_sin_cierre ON public.registros USING btree (id) WHERE ((cierre_id IS NULL) AND (estado = 'salio'::text));


--
-- Name: una_entrada_por_dia; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX una_entrada_por_dia ON public.movimientos_mensualidad USING btree (mensualidad_id, (((fecha AT TIME ZONE 'America/Bogota'::text))::date)) WHERE (movimiento = 'entrada'::text);


--
-- Name: movimientos_mensualidad movimientos_mensualidad_mensualidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_mensualidad
    ADD CONSTRAINT movimientos_mensualidad_mensualidad_id_fkey FOREIGN KEY (mensualidad_id) REFERENCES public.mensualidades(id) ON DELETE CASCADE;


--
-- Name: pagos_mensualidad pagos_mensualidad_cierre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagos_mensualidad
    ADD CONSTRAINT pagos_mensualidad_cierre_id_fkey FOREIGN KEY (cierre_id) REFERENCES public.cierres_caja(id);


--
-- Name: pagos_mensualidad pagos_mensualidad_mensualidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagos_mensualidad
    ADD CONSTRAINT pagos_mensualidad_mensualidad_id_fkey FOREIGN KEY (mensualidad_id) REFERENCES public.mensualidades(id) ON DELETE SET NULL;


--
-- Name: registros registros_cierre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registros
    ADD CONSTRAINT registros_cierre_id_fkey FOREIGN KEY (cierre_id) REFERENCES public.cierres_caja(id);


--
-- Name: cierres_caja; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cierres_caja ENABLE ROW LEVEL SECURITY;

--
-- Name: configuracion; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.configuracion ENABLE ROW LEVEL SECURITY;

--
-- Name: gastos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.gastos ENABLE ROW LEVEL SECURITY;

--
-- Name: mensualidades; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mensualidades ENABLE ROW LEVEL SECURITY;

--
-- Name: movimientos_mensualidad; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.movimientos_mensualidad ENABLE ROW LEVEL SECURITY;

--
-- Name: pagos_mensualidad; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pagos_mensualidad ENABLE ROW LEVEL SECURITY;

--
-- Name: registros; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.registros ENABLE ROW LEVEL SECURITY;

--
-- Name: resumen_diario; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.resumen_diario ENABLE ROW LEVEL SECURITY;

--
-- Name: tarifas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tarifas ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict kpAmxlA5aDycexKMPMq3r4mMuWDCBMbhgH4ksQl8unUtz02OiyJn9GbfbrZsO9Q

